@extends('master')

@section('title') CreaDent @endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/landing.css?v=1') }}">
@endsection

@section('main')

    <landing-component></landing-component>

@endsection
