<!DOCTYPE html>
<html lang="ru-RU">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:title" content="СШ Дельфин"/>
    <meta property="og:image" content="https://alpina-interiror.ru/img/fav.jpg" />
    <meta property="og:video:width" content="40" />
    <meta property="og:video:height" content="40" />
    <meta property="og:description" content="Плавение, спортивная борьба" />
    <meta property="og:url" content= "https://alpina-interior.ru/" />
    <meta name="keywords" content="
        плавание, борьба, спортивная школа, дельфин новороссийск, дельфин, спортивная борьба новороссийск, плавание новороссийск, борьба новороссийск, дельфин новороссийск, бассейн, бассейн новороссийск
    ">

    <title>@yield('title')</title>

    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/js/uikit-icons.min.js"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS -->
    {{--    <link rel="icon" href="{{ asset('css/favicon.png') }}" type="image/x-icon"/>--}}
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/glob.css?v=1') }}">
    <link rel="stylesheet" href="{{ asset('css/header.css?v=1') }}">
@yield('css')

<!-- Scripts -->
    <script src="{{ asset('js/app.js?v=1') }}" defer></script>

</head>
<body>

<section id="app">
    <h1 hidden></h1>
    @include('layouts.header')
    @yield('main')
    <div class="container footer-container">
        <a href="/admin" class="hide-btn">админка</a>
        <div class="row">
            <div class="col-12 d-flex">
                <span class="copyright">&copy; СШ "Дельфин" {{ \Illuminate\Support\Carbon::now()->format("Y") }}</span>
            </div>
        </div>
    </div>
</section>



</body>
</html>
