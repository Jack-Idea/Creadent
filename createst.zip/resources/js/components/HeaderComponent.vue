<template>
    <section class="header-section" uk-sticky="bottom: #offset">
        <div class="container">
            <div class="row" style="padding-bottom: 5px;">
                <div class="col-12 d-flex justify-content-between" style="align-items: center;">
                    <div class="logo uk-animation-slide-top">
                        <a href="/">
                            <img src="/img/logo-delfin2.png" alt="">
                        </a>
                    </div>
                    <div class="d-none d-lg-flex" style="flex-direction: column; justify-content: center;">
                        <p class="header-description">Муниципальное автономное учреждение</p>
                        <h2 class="header-description" style="font-size: 22px;">Спортивная школа &laquo;Дельфин&raquo;</h2>
                        <p class="header-description">г. Новороссийск</p>
                    </div>
                    <div class="logo uk-animation-slide-top">
                        <a href="" style="border-radius: 50%; overflow: hidden;">
                            <img src="/img/logo-struggle.png" alt="">
                        </a>
                    </div>
                    <!-- MOBILE BURGER MENU -->
                    <div class="menu-btn d-lg-none" uk-toggle="target: #offcanvas-flip">
                        <span class="menu-btn__line" uk-icon="icon: menu; ratio: 2.5;"></span>
                    </div>
                    <div id="offcanvas-flip" uk-offcanvas="flip: true; overlay: true">
                        <div class="uk-offcanvas-bar">

                            <button class="uk-offcanvas-close" type="button" uk-close></button>

                            <a href="/" class="mobile-menu-link uk-animation-slide-left"><span class="menu-chevron" uk-icon="icon: chevron-double-right;"></span> Главная</a>
                            <a href="/about" class="mobile-menu-link uk-animation-slide-right"><span class="menu-chevron" uk-icon="icon: chevron-double-right;"></span> О школе</a>
                            <a href="/docs" class="mobile-menu-link uk-animation-slide-left"><span class="menu-chevron" uk-icon="icon: chevron-double-right;"></span> Документы</a>
                            <a href="/kinds" class="mobile-menu-link uk-animation-slide-right"><span class="menu-chevron" uk-icon="icon: chevron-double-right;"></span> Виды спорта</a>
                            <a href="/news" class="mobile-menu-link uk-animation-slide-left"><span class="menu-chevron" uk-icon="icon: chevron-double-right;"></span> Новости</a>
                            <a href="/contacts" class="mobile-menu-link uk-animation-slide-right"><span class="menu-chevron" uk-icon="icon: chevron-double-right;"></span> Контакты</a>
                            <img src="/img/logo-delfin2.png" class="logo mobile-menu-logo" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center d-none d-lg-flex" style="padding: 5px 105px; border-top: 1px solid #222;">
                <div class="header-link">
                    <a href="/">Главная</a>
                </div>
                <div class="header-link">
                    <a href="/about">О школе</a>
                </div>
                <div class="header-link">
                    <a href="/docs">Документы</a>
                </div>
                <div class="header-link">
                    <a href="/kinds">Виды спорта</a>
                </div>
                <div class="header-link">
                    <a href="/news">Новости</a>
                </div>
                <div class="header-link">
                    <a href="/contacts">Контакты</a>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                transitionBtn: false
            }
        },
        mounted() {

        },
        methods: {

        }
    }
</script>
