<template>
    <section class="">
        <div class="container hero-section">

        </div>
    </section>
</template>

<script>
    export default {
        data() {
            return {

            }
        },
        mounted() {

        },
        methods: {

        }
    }
</script>
