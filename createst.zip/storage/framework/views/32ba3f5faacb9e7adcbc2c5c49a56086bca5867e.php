<header-component></header-component>
<?php /**PATH C:\wamp64-2\www\creadent\resources\views/layouts/header.blade.php ENDPATH**/ ?>