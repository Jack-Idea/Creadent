<?php $__env->startSection('title'); ?> CreaDent <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/landing.css?v=1')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <landing-component></landing-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64-2\www\creadent\resources\views/layouts/landing.blade.php ENDPATH**/ ?>