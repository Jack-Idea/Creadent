<!DOCTYPE html>
<html lang="ru-RU">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:title" content="СШ Дельфин"/>
    <meta property="og:image" content="https://alpina-interiror.ru/img/fav.jpg" />
    <meta property="og:video:width" content="40" />
    <meta property="og:video:height" content="40" />
    <meta property="og:description" content="Плавение, спортивная борьба" />
    <meta property="og:url" content= "https://alpina-interior.ru/" />
    <meta name="keywords" content="
        плавание, борьба, спортивная школа, дельфин новороссийск, дельфин, спортивная борьба новороссийск, плавание новороссийск, борьба новороссийск, дельфин новороссийск, бассейн, бассейн новороссийск
    ">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/js/uikit-icons.min.js"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS -->
    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/glob.css?v=1')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/header.css?v=1')); ?>">
<?php echo $__env->yieldContent('css'); ?>

<!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js?v=1')); ?>" defer></script>

</head>
<body>

<section id="app">
    <h1 hidden></h1>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('main'); ?>
    <div class="container footer-container">
        <a href="/admin" class="hide-btn">админка</a>
        <div class="row">
            <div class="col-12 d-flex">
                <span class="copyright">&copy; СШ "Дельфин" <?php echo e(\Illuminate\Support\Carbon::now()->format("Y")); ?></span>
            </div>
        </div>
    </div>
</section>



</body>
</html>
<?php /**PATH C:\wamp64-2\www\creadent\resources\views/master.blade.php ENDPATH**/ ?>