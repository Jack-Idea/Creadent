<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\AdminController;
use NotificationChannels\Telegram\TelegramChannel;
use NotificationChannels\Telegram\TelegramMessage;
use App\Notifications\Telegram;
use Illuminate\Support\Facades\Notification;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', [LandingController::class, 'index'])->name('landing');


Auth::routes();

// TELEGRAM BOT
Notification::route('telegram', '1149716004')
    ->notify(new Telegram);

Route::get('/admin', [App\Http\Controllers\AdminController::class, 'index'])->name('home');
