<?php $__env->startSection('title'); ?> Специалисты <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/employees.css?v=1')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <employees-component></employees-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64-2\www\creadent\resources\views/layouts/employees.blade.php ENDPATH**/ ?>