Имя: <?php echo e($name); ?>

<br>
Телефон: <?php echo e($phone); ?>

<br>
Вопрос: <?php echo e($date); ?>

<br>
Вопрос: <?php echo e($time); ?>

<?php /**PATH C:\wamp64-2\www\creadent\resources\views/layouts/callback-mail.blade.php ENDPATH**/ ?>