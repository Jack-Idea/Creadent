Имя: {{ $name }}
<br>
Телефон: {{ $phone }}
<br>
Вопрос: {{ $date }}
<br>
Вопрос: {{ $time }}
