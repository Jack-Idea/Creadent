@extends('master')

@section('title') CreaDent @endsection

@section('css')
@endsection

@section('main')

    <landing-component></landing-component>

@endsection
