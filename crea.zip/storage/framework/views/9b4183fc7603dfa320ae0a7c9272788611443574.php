<!DOCTYPE html>
<html lang="ru-RU">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:title" content="Creadent"/>

    <meta property="og:video:width" content="40" />
    <meta property="og:video:height" content="40" />
    <meta property="og:description" content="Стоматологическая клиника" />

    <meta name="keywords" content="
        Стоматология новороссийск, лечение зубов новороссийск, зубы новороссийск
    ">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.3.3/dist/js/uikit-icons.min.js"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500;600;700;800;900&family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS -->
    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/glob.css?v=1')); ?>">
<?php echo $__env->yieldContent('css'); ?>

<!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js?v=1')); ?>" defer></script>

</head>
<body>

<div id="app">
    <h1 hidden></h1>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('main'); ?>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>



</body>
</html>
<?php /**PATH C:\wamp64-2\www\creadent\resources\views/master.blade.php ENDPATH**/ ?>