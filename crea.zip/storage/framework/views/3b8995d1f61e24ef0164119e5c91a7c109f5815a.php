<?php $__env->startSection('title'); ?> О клинике <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/about.css?v=1')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <about-component></about-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64-2\www\creadent\resources\views/layouts/about.blade.php ENDPATH**/ ?>