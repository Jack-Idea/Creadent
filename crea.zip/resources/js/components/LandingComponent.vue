<template>
    <section class="">
        <section id="mainSec" class="hero" :style="'height:'+heroH+'px; max-height: 820px; position: relative;'">
            <div class="container hero-section">
                <div class="row">
                    <div class="col-12">
                        <img src="/img/main-bg.jpg" class="d-none d-lg-flex main-bg" alt="">
                        <div class="main-offer">
                            <h1 class="main-offer__title">
                                Стоматологическая клиника creadent
                            </h1>
                            <h3 class="main-offer__description">
                                Доверьте нам вашу улыбку
                            </h3>
                            <div class="main-offer__btn d-none d-lg-flex">
                                Записаться на прием
                            </div>
                        </div>
                    </div>
                </div>
                <img src="/img/interval-group.png" class="interval-img d-none d-lg-flex" alt="">
            </div>
            <img src="/img/main-bg-mobile.jpg" class="mobile-bg-img d-flex d-lg-none" alt="">
            <div class="mobile-main-btn d-flex d-lg-none">
                <div class="main-offer__btn">
                    Записаться на прием
                </div>
            </div>
<!--            <section class="mobile-bg-sec d-flex d-lg-none"></section>-->
        </section>
        <section class="interval-section d-none d-lg-flex">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-6">
                    </div>
                    <div class="col-12 col-lg-6">
                        <div class="interval-lines-wrap">
                            <span class="interval-line interval-line-one"></span>
                            <span class="interval-line interval-line-two"></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="second-section section-padding pb-0">
            <div class="container second-sec-cont">
                <div class="row second-sec-row">
                    <img src="/img/crea-bg-text.png" class="crea-bg-text" alt="">
                    <div class="col-12 col-lg-5">
                        <img src="/img/second-sec.png" alt="">
                    </div>
                    <div class="col-12 col-lg-7">
                        <div class="second-sec-text-wrap">
                            <p class="second-sec-text">
                                Наша клиника обеспечивает комфорт пациента во время стоматологических процедур, заботясь о каждом пациенте. Светлые кабинеты, приятная обстановка, отличный сервис, а главное вы забудете, что находитесь в стоматологии и сможете расслабиться.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="servicesSec" class="third-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="page-title">
                            Услуги
                        </h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-4">
                        <div class="service-card">
                            <img src="/img/terapy-img.png" class="service-card__bg" alt="">
                            <h3 class="service-card__text">Терапия</h3>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="service-card">
                            <img src="/img/kids.png" class="service-card__bg" alt="">
                            <h3 class="service-card__text">Детская <br> стоматология</h3>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="service-card">
                            <img src="/img/implantation.png" class="service-card__bg" alt="">
                            <h3 class="service-card__text">Имплантация</h3>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="service-card">
                            <img src="/img/surgery.png" class="service-card__bg" alt="">
                            <h3 class="service-card__text">Хирургия</h3>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="service-card">
                            <img src="/img/orthodontics.png" class="service-card__bg" alt="">
                            <h3 class="service-card__text">Ортодонтия</h3>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="service-card">
                            <img src="/img/prosthetics.png" class="service-card__bg" alt="">
                            <h3 class="service-card__text">Протезирование</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--    ABOUT SEC    -->
        <section class="about-section section-padding pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="page-title">
                            О нас
                        </h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-5">
                        <div class="about-text-wrap">
                            <p class="second-sec-text about-text">
                                Клиника CREADENT предоставляет весь спектр стоматологических услуг.
                                Для каждого пациента мы подбираем индивидуальный комплексный план лечения зубов, с учетом всех имеющихся у пациента стоматологических патологий. Взаимодействие врачей стоматологов из разных специализаций, дают возможность проведения смежной консультации в одно посещение.
                            </p>
                            <p class="second-sec-text about-text">
                                В клинике CREADENT есть собственная зуботехническая лаборатория, которая позволяет сократить сроки при лечении.
                            </p>
                            <div class="interval-lines-wrap mt-0">
                                <span class="interval-line interval-line-one ml-5"></span>
                                <span class="interval-line interval-line-two ml-0"></span>
                            </div>
                            <a href="/about" class="main-offer__btn">
                                Подробнее
                            </a>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 ml-auto">
                        <img src="/img/about-img1.png" alt="">
                        <div class="interval-lines-wrap mt-5">
                            <span class="interval-line interval-line-one mr-5"></span>
                            <span class="interval-line interval-line-two"></span>
                        </div>
                        <img src="/img/about-img2.png" class="d-flex mt-3" alt="">
                    </div>
                </div>
            </div>
        </section>
        <!--    EMPLOYEES SEC    -->
        <section class="about-section section-padding pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="page-title">
                            Сотрудники
                        </h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <img src="/img/employees.jpg" style="position: relative; z-index: 10;" alt="">
                    </div>
                    <div class="col-12 col-lg-5 ml-auto">
                        <div class="about-text-wrap justify-content-center mt-3 mt-lg-0">
                            <p class="second-sec-text about-text">
                                В клинике CREADENT работают высококвалифицированные специалисты, которые окажут вам лучшее лечение и сервис в городе. Мы используем комплексный подход, основанный на составлении индивидуального плана лечения для каждого пациента.
                            </p>
                            <div class="interval-lines-wrap mt-3 mt-lg-4">
                                <span class="interval-line interval-line-one ml-0"></span>
                                <span class="interval-line interval-line-two ml-5 mb-0"></span>
                            </div>
                            <a href="/employees" class="main-offer__btn mt-5">
                                Подробнее
                            </a>
                            <img src="/img/crea-bg-text.png" class="crea-bg-text eployees-bg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                heroH: ''
            }
        },
        mounted() {

        },
        methods: {
        },
        computed: {
            heroHeight() {
                document.addEventListener('DOMContentLoaded', () => {
                    let H = window.innerHeight
                    this.heroH = H-80
                    console.log(H)
                })
            }
        },
        watch: {
            heroHeight() {
                document.addEventListener('DOMContentLoaded', () => {
                    let H = window.innerHeight
                    this.heroH = H-80
                    console.log(H)
                })
            }
        }
    }
</script>
