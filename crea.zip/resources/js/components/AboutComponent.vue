<template>
    <section>
        <div class="container">

        </div>
    </section>
</template>

<script>
    import logo from '/img/main-logo.png';
    export default {
        data() {
            return {
                preloader: true,
                logo,
            }
        },
        mounted() {
            console.log('about mounted.')
        },
        methods: {
        }
    }
</script>
